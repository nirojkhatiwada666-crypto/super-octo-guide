# Hamro NET FTTH Management Portal

A Vite + React + TypeScript frontend based on the supplied Hamro NET portal component. Styling uses Tailwind CSS and icons use Lucide React.

## Run locally

1. Install Node.js 20 or newer.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local address printed by Vite (usually `http://localhost:5173`).

## Production build

Run `npm run build`, then `npm run preview` to preview the built site.

## Important

This is a frontend starter. Customer, billing, and ticket data in the supplied component are demo/client-side state; it is not connected to a secure production database, payment provider, or real OLT hardware. Connect an authenticated backend before using it with real customer data.
