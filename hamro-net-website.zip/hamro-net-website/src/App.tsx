import React, { useState, useMemo, useEffect } from 'react';
import { 
  Users, 
  Wifi, 
  Clock, 
  AlertTriangle, 
  Plus, 
  Search, 
  Filter, 
  RefreshCw, 
  Activity, 
  Phone, 
  MapPin, 
  Calendar, 
  CheckCircle, 
  XCircle, 
  Eye, 
  Receipt, 
  Printer, 
  X, 
  Server, 
  ChevronRight,
  TrendingUp,
  SlidersHorizontal,
  CreditCard,
  Ticket,
  Settings,
  Languages,
  Radio,
  ArrowUpDown,
  Download,
  Building2,
  Package,
  Wrench,
  ShieldAlert,
  Zap,
  Check,
  ChevronLeft
} from 'lucide-react';

// --- DICTIONARY FOR NEPALI / ENGLISH ---
const TRANSLATIONS = {
  en: {
    brand: "Hamro NET",
    subBrand: "FTTH ISP Management Portal",
    dashboard: "Dashboard & Customers",
    diagnostics: "Fiber Diagnostics & OLT",
    tickets: "Field Tickets & Complaints",
    settings: "Branch & Package Settings",
    addCustomer: "Add Customer",
    totalSubscribers: "Total Subscribers",
    activeConnections: "Active Connections",
    expiredSubscribers: "Expired / Due Renewal",
    pendingSetup: "Pending Installation",
    searchPlaceholder: "Search by Name, Phone, ID, MAC...",
    allBranches: "All Branches",
    allStatuses: "All Statuses",
    allPackages: "All Speed Packages",
    branch: "Branch / Ward",
    package: "Package",
    status: "Status",
    actions: "Actions",
    renew: "Renew",
    details: "Details",
    signalCheck: "Signal Check",
    billInvoice: "Generate Bill",
    receiptTitle: "TAX INVOICE / RECEIPT",
    vatNo: "PAN/VAT No: 601234567",
    printInvoice: "Print / Save Invoice",
    close: "Close",
    registerTitle: "Register New Subscriber",
    name: "Customer Full Name",
    mobile: "Mobile Number",
    oltPort: "OLT PON Port",
    onuMac: "ONU MAC Address",
    fiberLength: "Fiber Cable Length (km)",
    splitterRatio: "Splitter Ratio",
    calculateSignal: "Calculate Optical Power",
    estSignal: "Estimated Optical Power (Rx)",
    saveCustomer: "Save & Activate Subscriber",
    ticketId: "Ticket ID",
    subject: "Issue Description",
    priority: "Priority",
    assignedTech: "Assigned Tech",
    createNewTicket: "Open Support Ticket",
    settingsHeader: "System Configuration & Tariff Plans",
    addBranch: "Add Branch",
    addPackage: "Add Package",
    language: "Language",
    itemsPerPage: "Rows Per Page",
    prev: "Prev",
    next: "Next",
    page: "Page"
  },
  np: {
    brand: "हाम्रो NET",
    subBrand: "इन्टरनेट सेवा व्यवस्थापन पोर्टल",
    dashboard: "ड्यासबोर्ड र ग्राहकहरू",
    diagnostics: "फाइबर सिग्नल र OLT जाँच",
    tickets: "गुनासो तथा फिल्ड टिकट",
    settings: "शाखा र प्याकेज सेटिङ",
    addCustomer: "नयाँ ग्राहक थप्नुहोस्",
    totalSubscribers: "कुल ग्राहक संख्या",
    activeConnections: "सक्रिय ग्राहकहरू",
    expiredSubscribers: "म्याद सकिएका ग्राहक",
    pendingSetup: "जडान बाँकी",
    searchPlaceholder: "नाम, फोन, ID वा MAC द्वारा खोज्नुहोस्...",
    allBranches: "सबै शाखाहरू",
    allStatuses: "सबै स्थिति",
    allPackages: "सबै प्याकेजहरू",
    branch: "शाखा / वडा",
    package: "इन्टरनेट प्याकेज",
    status: "स्थिति",
    actions: "कार्यहरू",
    renew: "नवीकरण",
    details: "विवरण",
    signalCheck: "सिग्नल जाँच",
    billInvoice: "बिल जारी गर्नुहोस्",
    receiptTitle: "कर बिजक / रसिद",
    vatNo: "पान/भ्याट नं: ६०१२३४५६७",
    printInvoice: "प्रिन्ट / डाउनलोड",
    close: "बन्द गर्नुहोस्",
    registerTitle: "नयाँ फाइबर ग्राहक दर्ता",
    name: "ग्राहकको पूरा नाम",
    mobile: "मोबाइल नम्बर",
    oltPort: "OLT पोन पोर्ट",
    onuMac: "ONU म्याक ठेगाना",
    fiberLength: "फाइबर तारको लम्बाई (कि.मी.)",
    splitterRatio: "स्प्लिटर अनुपात",
    calculateSignal: "सिग्नल गणना गर्नुहोस्",
    estSignal: "अनुमानित अप्टिकल सिग्नल (Rx)",
    saveCustomer: "सुरक्षित गरी सुचारु गर्नुहोस्",
    ticketId: "टिकट नं",
    subject: "समस्याको विवरण",
    priority: "प्राथमिकता",
    assignedTech: "प्राविधिक कर्मचारी",
    createNewTicket: "नयाँ टिकट दर्ता",
    settingsHeader: "प्रणाली व्यवस्थापन तथा महसुल",
    addBranch: "शाखा थप्नुहोस्",
    addPackage: "प्याकेज थप्नुहोस्",
    language: "भाषा (Language)",
    itemsPerPage: "प्रति पृष्ठ दर्ता",
    prev: "अघिल्लो",
    next: "पछिल्लो",
    page: "पृष्ठ"
  }
};

const INITIAL_BRANCHES = [
  "Nijgadh Ward No. 5",
  "Nijgadh Ward No. 8",
  "Nijgadh Ward No. 12 / Ramthali",
  "Kolhabi Road / Ward 3",
  "Ratanpuri Branch"
];

const INITIAL_PACKAGES = [
  { id: "p1", name: "50 Mbps FTTH Basic", speed: "50 Mbps", price: 850, tax: 110.5 },
  { id: "p2", name: "100 Mbps Dual Band", speed: "100 Mbps", price: 1200, tax: 156.0 },
  { id: "p3", name: "200 Mbps Ultra Fiber", speed: "200 Mbps", price: 1750, tax: 227.5 },
  { id: "p4", name: "300 Mbps Giga Stream", speed: "300 Mbps", price: 2400, tax: 312.0 }
];

const INITIAL_CUSTOMERS = [
  {
    id: "HN-2026-001",
    name: "Ram Bahadur Thapa",
    mobile: "9845012345",
    branch: "Nijgadh Ward No. 5",
    package: "100 Mbps Dual Band",
    price: 1200,
    expiryDate: "2026-11-15",
    daysRemaining: 19,
    status: "Active",
    oltPort: "OLT-01/PON-02",
    onuMac: "48:57:DD:A1:8B:12",
    opticalSignal: "-19.50",
    distanceKm: 1.2,
    splitter: "1:8"
  },
  {
    id: "HN-2026-002",
    name: "Sita Kumari Sharma",
    mobile: "9812345678",
    branch: "Nijgadh Ward No. 12 / Ramthali",
    package: "50 Mbps FTTH Basic",
    price: 850,
    expiryDate: "2026-10-25",
    daysRemaining: -2,
    status: "Expired",
    oltPort: "OLT-02/PON-01",
    onuMac: "28:60:46:C3:9A:04",
    opticalSignal: "-27.80",
    distanceKm: 4.8,
    splitter: "1:16"
  },
  {
    id: "HN-2026-003",
    name: "Hari Prasad Dahal",
    mobile: "9807654321",
    branch: "Nijgadh Ward No. 8",
    package: "200 Mbps Ultra Fiber",
    price: 1750,
    expiryDate: "2026-12-01",
    daysRemaining: 35,
    status: "Active",
    oltPort: "OLT-01/PON-04",
    onuMac: "00:1A:2B:3C:4D:5E",
    opticalSignal: "-18.20",
    distanceKm: 0.8,
    splitter: "1:8"
  },
  {
    id: "HN-2026-004",
    name: "Gita Devi Shrestha",
    mobile: "9861122334",
    branch: "Nijgadh Ward No. 5",
    package: "50 Mbps FTTH Basic",
    price: 850,
    expiryDate: "2026-10-26",
    daysRemaining: -1,
    status: "Expired",
    oltPort: "OLT-03/PON-02",
    onuMac: "C4:A8:1D:8E:9F:00",
    opticalSignal: "-21.10",
    distanceKm: 2.1,
    splitter: "1:8"
  },
  {
    id: "HN-2026-005",
    name: "Bikash Gurung",
    mobile: "9818899000",
    branch: "Kolhabi Road / Ward 3",
    package: "100 Mbps Dual Band",
    price: 1200,
    expiryDate: "2026-10-30",
    daysRemaining: 3,
    status: "Active",
    oltPort: "OLT-02/PON-03",
    onuMac: "8C:11:CB:44:55:66",
    opticalSignal: "-20.10",
    distanceKm: 1.9,
    splitter: "1:16"
  },
  {
    id: "HN-2026-006",
    name: "Anil Chaudhary",
    mobile: "9801122445",
    branch: "Nijgadh Ward No. 12 / Ramthali",
    package: "300 Mbps Giga Stream",
    price: 2400,
    expiryDate: "2026-11-20",
    daysRemaining: 24,
    status: "Pending Installation",
    oltPort: "OLT-01/PON-08",
    onuMac: "E4:90:7A:11:22:33",
    opticalSignal: "-22.40",
    distanceKm: 3.0,
    splitter: "1:16"
  }
];

const INITIAL_TICKETS = [
  {
    id: "TCK-801",
    customerName: "Sita Kumari Sharma",
    phone: "9812345678",
    branch: "Nijgadh Ward No. 12 / Ramthali",
    issue: "Red LOS Light blinking (Fiber break suspect near pole 42)",
    priority: "High",
    status: "In Progress",
    tech: "Suman Giri",
    date: "2026-10-26"
  },
  {
    id: "TCK-802",
    customerName: "Bikash Gurung",
    phone: "9818899000",
    branch: "Kolhabi Road / Ward 3",
    issue: "Slow speed on 5GHz Wi-Fi router relocation request",
    priority: "Medium",
    status: "Open",
    tech: "Unassigned",
    date: "2026-10-27"
  }
];

export default function App() {
  // --- STATE PERSISTENCE & APP CONTROL ---
  const [lang, setLang] = useState('np');
  const t = TRANSLATIONS[lang];

  const [activeTab, setActiveTab] = useState('dashboard'); // 'dashboard', 'diagnostics', 'tickets', 'settings'
  
  // Data State
  const [customers, setCustomers] = useState(() => {
    const saved = localStorage.getItem('hn_customers');
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [branches, setBranches] = useState(() => {
    const saved = localStorage.getItem('hn_branches');
    return saved ? JSON.parse(saved) : INITIAL_BRANCHES;
  });

  const [packages, setPackages] = useState(() => {
    const saved = localStorage.getItem('hn_packages');
    return saved ? JSON.parse(saved) : INITIAL_PACKAGES;
  });

  const [tickets, setTickets] = useState(() => {
    const saved = localStorage.getItem('hn_tickets');
    return saved ? JSON.parse(saved) : INITIAL_TICKETS;
  });

  useEffect(() => {
    localStorage.setItem('hn_customers', JSON.stringify(customers));
    localStorage.setItem('hn_branches', JSON.stringify(branches));
    localStorage.setItem('hn_packages', JSON.stringify(packages));
    localStorage.setItem('hn_tickets', JSON.stringify(tickets));
  }, [customers, branches, packages, tickets]);

  // Filtering, Search, Sorting, Pagination
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBranch, setSelectedBranch] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [selectedPackage, setSelectedPackage] = useState('All');
  const [sortField, setSortField] = useState('name');
  const [sortOrder, setSortOrder] = useState('asc');

  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(5);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [renewingCustomer, setRenewingCustomer] = useState(null);
  const [viewingCustomer, setViewingCustomer] = useState(null);
  const [receiptData, setReceiptData] = useState(null);
  const [isTicketModalOpen, setIsTicketModalOpen] = useState(false);

  // Optical Signal Calculator State
  const [calcDistance, setCalcDistance] = useState(2.5);
  const [calcSplitter, setCalcSplitter] = useState('1:16'); // 1:8 (-10.5dB), 1:16 (-14dB), 1:32 (-17.5dB)
  const [calcTxPower, setCalcTxPower] = useState(3.0); // dBm from OLT SFP

  // Calculate dBm
  const calculatedRxSignal = useMemo(() => {
    let splitterLoss = 14.0;
    if (calcSplitter === '1:4') splitterLoss = 7.0;
    if (calcSplitter === '1:8') splitterLoss = 10.5;
    if (calcSplitter === '1:16') splitterLoss = 14.0;
    if (calcSplitter === '1:32') splitterLoss = 17.5;

    const fiberAttenuationPerKm = 0.35; // 1310nm/1490nm avg dB loss/km
    const spliceLoss = 0.5; // avg patch panel / fusion splice loss
    const totalLoss = (calcDistance * fiberAttenuationPerKm) + splitterLoss + spliceLoss;
    const rxPower = calcTxPower - totalLoss;
    return rxPower.toFixed(2);
  }, [calcDistance, calcSplitter, calcTxPower]);

  // Form States
  const [newCust, setNewCust] = useState({
    name: '',
    mobile: '',
    branch: INITIAL_BRANCHES[0],
    package: INITIAL_PACKAGES[1].name,
    oltPort: 'OLT-01/PON-01',
    distanceKm: 2.0,
    splitter: '1:16'
  });

  const [newTicket, setNewTicket] = useState({
    customerName: '',
    phone: '',
    branch: INITIAL_BRANCHES[0],
    issue: '',
    priority: 'Medium',
    tech: 'Suman Giri'
  });

  const [newBranchInput, setNewBranchInput] = useState('');
  const [newPkgInput, setNewPkgInput] = useState({ name: '', speed: '', price: '' });

  // Filtered & Sorted Customer Data
  const filteredCustomers = useMemo(() => {
    return customers.filter(c => {
      const matchSearch = 
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.mobile.includes(searchQuery) ||
        c.onuMac.toLowerCase().includes(searchQuery.toLowerCase());

      const matchBranch = selectedBranch === 'All' || c.branch === selectedBranch;
      const matchStatus = selectedStatus === 'All' || c.status === selectedStatus;
      const matchPackage = selectedPackage === 'All' || c.package === selectedPackage;

      return matchSearch && matchBranch && matchStatus && matchPackage;
    }).sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];
      if (typeof aVal === 'string') aVal = aVal.toLowerCase();
      if (typeof bVal === 'string') bVal = bVal.toLowerCase();

      if (aVal < bVal) return sortOrder === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });
  }, [customers, searchQuery, selectedBranch, selectedStatus, selectedPackage, sortField, sortOrder]);

  // Pagination Logic
  const totalPages = Math.ceil(filteredCustomers.length / pageSize) || 1;
  const paginatedCustomers = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredCustomers.slice(start, start + pageSize);
  }, [filteredCustomers, currentPage, pageSize]);

  // Stats
  const stats = useMemo(() => {
    const total = customers.length;
    const active = customers.filter(c => c.status === "Active").length;
    const expired = customers.filter(c => c.status === "Expired").length;
    const pending = customers.filter(c => c.status === "Pending Installation").length;
    return { total, active, expired, pending };
  }, [customers]);

  // Handlers
  const handleSort = (field) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const handleAddCustomer = (e) => {
    e.preventDefault();
    const pkgDetails = packages.find(p => p.name === newCust.package);
    const price = pkgDetails ? pkgDetails.price : 1200;

    // Auto calculate dBm for registration
    let splitterLoss = newCust.splitter === '1:8' ? 10.5 : newCust.splitter === '1:32' ? 17.5 : 14.0;
    const rxSignal = (3.0 - ((parseFloat(newCust.distanceKm) * 0.35) + splitterLoss + 0.5)).toFixed(2);

    const randomMacPart = Math.floor(Math.random()*89+10) + ":" + Math.floor(Math.random()*89+10);
    const newEntry = {
      id: `HN-2026-00${customers.length + 1}`,
      name: newCust.name,
      mobile: newCust.mobile,
      branch: newCust.branch,
      package: newCust.package,
      price: price,
      expiryDate: new Date(Date.now() + 30*24*60*60*1000).toISOString().split('T')[0],
      daysRemaining: 30,
      status: "Active",
      oltPort: newCust.oltPort,
      onuMac: `48:57:DD:F0:${randomMacPart}`,
      opticalSignal: rxSignal,
      distanceKm: parseFloat(newCust.distanceKm),
      splitter: newCust.splitter
    };

    setCustomers([newEntry, ...customers]);
    setIsAddModalOpen(false);
    setNewCust({
      name: '',
      mobile: '',
      branch: branches[0],
      package: packages[0]?.name || '',
      oltPort: 'OLT-01/PON-01',
      distanceKm: 2.0,
      splitter: '1:16'
    });
  };

  const handleRenew = (months) => {
    if (!renewingCustomer) return;
    const addedDays = months * 30;
    
    const updated = customers.map(c => {
      if (c.id === renewingCustomer.id) {
        const currentDays = Math.max(0, c.daysRemaining);
        const newDays = currentDays + addedDays;
        const newExpDate = new Date();
        newExpDate.setDate(newExpDate.getDate() + newDays);

        return {
          ...c,
          daysRemaining: newDays,
          expiryDate: newExpDate.toISOString().split('T')[0],
          status: "Active"
        };
      }
      return c;
    });

    const targetCust = updated.find(c => c.id === renewingCustomer.id);
    setCustomers(updated);

    const subTotal = targetCust.price * months;
    const vatAmount = subTotal * 0.13;
    const totalWithVat = subTotal + vatAmount;

    setReceiptData({
      invoiceNo: `VAT-2026-${Math.floor(10000 + Math.random() * 90000)}`,
      customer: targetCust,
      months,
      subTotal,
      vatAmount,
      totalWithVat,
      date: new Date().toISOString().split('T')[0]
    });

    setRenewingCustomer(null);
  };

  const handleAddTicket = (e) => {
    e.preventDefault();
    const tck = {
      id: `TCK-${Math.floor(800 + Math.random()*100)}`,
      ...newTicket,
      status: 'Open',
      date: new Date().toISOString().split('T')[0]
    };
    setTickets([tck, ...tickets]);
    setIsTicketModalOpen(false);
    setNewTicket({ customerName: '', phone: '', branch: branches[0], issue: '', priority: 'Medium', tech: 'Suman Giri' });
  };

  const handleAddBranch = () => {
    if (!newBranchInput.trim()) return;
    setBranches([...branches, newBranchInput.trim()]);
    setNewBranchInput('');
  };

  const handleAddPackage = () => {
    if (!newPkgInput.name || !newPkgInput.price) return;
    const priceNum = parseFloat(newPkgInput.price);
    const newPkg = {
      id: `p${packages.length + 1}`,
      name: newPkgInput.name,
      speed: newPkgInput.speed || `${newPkgInput.name}`,
      price: priceNum,
      tax: priceNum * 0.13
    };
    setPackages([...packages, newPkg]);
    setNewPkgInput({ name: '', speed: '', price: '' });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col antialiased selection:bg-cyan-500 selection:text-white">
      
      {/* HEADER / NAVIGATION BAR */}
      <header className="bg-slate-900/90 border-b border-slate-800 sticky top-0 z-30 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          
          {/* Logo */}
          <div className="flex items-center space-x-3 shrink-0 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <Wifi className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold tracking-tight text-white">
                  {t.brand}
                </h1>
                <span className="bg-cyan-500/10 text-cyan-400 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-cyan-500/30">
                  FTTH GPON
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">{t.subBrand}</p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'dashboard' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{t.dashboard}</span>
            </button>
            <button
              onClick={() => setActiveTab('diagnostics')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'diagnostics' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>{t.diagnostics}</span>
            </button>
            <button
              onClick={() => setActiveTab('tickets')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'tickets' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Ticket className="w-3.5 h-3.5" />
              <span>{t.tickets}</span>
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                activeTab === 'settings' ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>{t.settings}</span>
            </button>
          </nav>

          {/* Right Header Actions */}
          <div className="flex items-center space-x-3">
            {/* Language Switcher */}
            <button
              onClick={() => setLang(lang === 'en' ? 'np' : 'en')}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-xs font-medium text-slate-200 transition"
              title="Toggle Language"
            >
              <Languages className="w-3.5 h-3.5 text-cyan-400" />
              <span>{lang === 'en' ? 'नेपाली' : 'English'}</span>
            </button>

            {/* Quick Add CTA */}
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="inline-flex items-center space-x-1.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white px-3.5 py-1.5 rounded-lg text-xs font-semibold shadow-md shadow-cyan-500/20 transition active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">{t.addCustomer}</span>
            </button>
          </div>
        </div>
      </header>

      {/* MOBILE TAB BAR */}
      <div className="md:hidden bg-slate-900 border-b border-slate-800 flex justify-around p-2 text-xs">
        <button onClick={() => setActiveTab('dashboard')} className={`p-2 rounded ${activeTab==='dashboard'?'text-cyan-400 bg-slate-800':''}`}>{t.dashboard}</button>
        <button onClick={() => setActiveTab('diagnostics')} className={`p-2 rounded ${activeTab==='diagnostics'?'text-cyan-400 bg-slate-800':''}`}>{t.diagnostics}</button>
        <button onClick={() => setActiveTab('tickets')} className={`p-2 rounded ${activeTab==='tickets'?'text-cyan-400 bg-slate-800':''}`}>{t.tickets}</button>
        <button onClick={() => setActiveTab('settings')} className={`p-2 rounded ${activeTab==='settings'?'text-cyan-400 bg-slate-800':''}`}>{t.settings}</button>
      </div>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">

        {/* --- TAB 1: CUSTOMERS & DASHBOARD --- */}
        {activeTab === 'dashboard' && (
          <>
            {/* STAT CARDS */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 flex items-center space-x-4">
                <div className="p-3 bg-blue-500/10 text-blue-400 rounded-lg border border-blue-500/20">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400">{t.totalSubscribers}</p>
                  <p className="text-2xl font-bold text-slate-100">{stats.total}</p>
                </div>
              </div>

              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 flex items-center space-x-4">
                <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-lg border border-emerald-500/20">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400">{t.activeConnections}</p>
                  <p className="text-2xl font-bold text-emerald-400">{stats.active}</p>
                </div>
              </div>

              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 flex items-center space-x-4">
                <div className="p-3 bg-rose-500/10 text-rose-400 rounded-lg border border-rose-500/20">
                  <XCircle className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400">{t.expiredSubscribers}</p>
                  <p className="text-2xl font-bold text-rose-400">{stats.expired}</p>
                </div>
              </div>

              <div className="bg-slate-900/70 border border-slate-800 rounded-xl p-4 flex items-center space-x-4">
                <div className="p-3 bg-amber-500/10 text-amber-400 rounded-lg border border-amber-500/20">
                  <Clock className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400">{t.pendingSetup}</p>
                  <p className="text-2xl font-bold text-amber-400">{stats.pending}</p>
                </div>
              </div>
            </div>

            {/* FILTER & SEARCH BAR */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-sm space-y-3">
              <div className="flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
                
                {/* Search Input */}
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder={t.searchPlaceholder}
                    value={searchQuery}
                    onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                  />
                </div>

                {/* Dropdown Filters */}
                <div className="grid grid-cols-3 gap-2">
                  <select
                    value={selectedBranch}
                    onChange={(e) => { setSelectedBranch(e.target.value); setCurrentPage(1); }}
                    className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:border-cyan-500"
                  >
                    <option value="All">{t.allBranches}</option>
                    {branches.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>

                  <select
                    value={selectedStatus}
                    onChange={(e) => { setSelectedStatus(e.target.value); setCurrentPage(1); }}
                    className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:border-cyan-500"
                  >
                    <option value="All">{t.allStatuses}</option>
                    <option value="Active">Active</option>
                    <option value="Expired">Expired</option>
                    <option value="Pending Installation">Pending</option>
                  </select>

                  <select
                    value={selectedPackage}
                    onChange={(e) => { setSelectedPackage(e.target.value); setCurrentPage(1); }}
                    className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-2 text-xs text-slate-200 focus:border-cyan-500"
                  >
                    <option value="All">{t.allPackages}</option>
                    {packages.map(p => (
                      <option key={p.id} value={p.name}>{p.name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* CUSTOMER DATA TABLE */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl shadow-lg overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="px-4 py-3 cursor-pointer hover:text-white" onClick={() => handleSort('name')}>
                        <div className="flex items-center space-x-1">
                          <span>Subscriber / ID</span>
                          <ArrowUpDown className="w-3 h-3" />
                        </div>
                      </th>
                      <th className="px-4 py-3 cursor-pointer hover:text-white" onClick={() => handleSort('branch')}>
                        <div className="flex items-center space-x-1">
                          <span>{t.branch}</span>
                          <ArrowUpDown className="w-3 h-3" />
                        </div>
                      </th>
                      <th className="px-4 py-3">{t.package}</th>
                      <th className="px-4 py-3 cursor-pointer hover:text-white" onClick={() => handleSort('expiryDate')}>
                        <div className="flex items-center space-x-1">
                          <span>Expiry / {t.status}</span>
                          <ArrowUpDown className="w-3 h-3" />
                        </div>
                      </th>
                      <th className="px-4 py-3">PON & Signal (Rx)</th>
                      <th className="px-4 py-3 text-right">{t.actions}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {paginatedCustomers.length > 0 ? (
                      paginatedCustomers.map((c) => {
                        const rxNum = parseFloat(c.opticalSignal);
                        const isSignalWeak = rxNum < -25.0;

                        return (
                          <tr key={c.id} className="hover:bg-slate-800/40 transition">
                            <td className="px-4 py-3.5">
                              <div className="font-semibold text-slate-100">{c.name}</div>
                              <div className="flex items-center space-x-2 mt-0.5 text-[11px] text-slate-400">
                                <span className="font-mono bg-slate-950 px-1.5 py-0.5 rounded text-cyan-400 border border-slate-800">
                                  {c.id}
                                </span>
                                <span>{c.mobile}</span>
                              </div>
                            </td>

                            <td className="px-4 py-3.5">
                              <div className="flex items-center text-slate-300">
                                <MapPin className="w-3.5 h-3.5 mr-1 text-slate-500 shrink-0" />
                                <span>{c.branch}</span>
                              </div>
                            </td>

                            <td className="px-4 py-3.5">
                              <div className="font-medium text-slate-200">{c.package}</div>
                              <div className="text-slate-400">रु. {c.price} / mo</div>
                            </td>

                            <td className="px-4 py-3.5">
                              <div className="space-y-1">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium ${
                                  c.status === "Active" 
                                    ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                                    : c.status === "Expired"
                                    ? "bg-rose-500/10 text-rose-400 border border-rose-500/20"
                                    : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                                }`}>
                                  {c.status}
                                </span>
                                <div className="text-[11px] text-slate-400">Exp: {c.expiryDate}</div>
                              </div>
                            </td>

                            <td className="px-4 py-3.5 font-mono">
                              <div>{c.oltPort}</div>
                              <div className={`text-[11px] font-semibold ${isSignalWeak ? 'text-rose-400' : 'text-emerald-400'}`}>
                                {c.opticalSignal} dBm
                              </div>
                            </td>

                            <td className="px-4 py-3.5 text-right space-x-1.5 whitespace-nowrap">
                              <button
                                onClick={() => setViewingCustomer(c)}
                                title={t.details}
                                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition"
                              >
                                <Eye className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => setRenewingCustomer(c)}
                                className="px-2.5 py-1.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 rounded-lg font-medium transition"
                              >
                                {t.renew}
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    ) : (
                      <tr>
                        <td colSpan="6" className="text-center py-8 text-slate-500">
                          No customer records found matching search filters.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* PAGINATION CONTROLS */}
              <div className="bg-slate-950 px-4 py-3 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-400">
                <div className="flex items-center space-x-2">
                  <span>{t.itemsPerPage}:</span>
                  <select 
                    value={pageSize}
                    onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1); }}
                    className="bg-slate-900 border border-slate-800 rounded px-2 py-1 text-slate-200"
                  >
                    <option value={5}>5</option>
                    <option value={10}>10</option>
                    <option value={20}>20</option>
                  </select>
                </div>

                <div>
                  {t.page} <span className="text-slate-200 font-semibold">{currentPage}</span> of <span className="text-slate-200 font-semibold">{totalPages}</span>
                </div>

                <div className="flex items-center space-x-1">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 border border-slate-800 rounded"
                  >
                    {t.prev}
                  </button>
                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 disabled:opacity-40 border border-slate-800 rounded"
                  >
                    {t.next}
                  </button>
                </div>
              </div>
            </div>
          </>
        )}

        {/* --- TAB 2: FIBER DIAGNOSTICS & OLT CALCULATOR --- */}
        {activeTab === 'diagnostics' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* OLT / Optical Power Simulator */}
            <div className="lg:col-span-1 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <div className="flex items-center space-x-2 pb-3 border-b border-slate-800">
                <Radio className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-slate-100">GPON Optical Power Calculator</h3>
              </div>
              <p className="text-xs text-slate-400">
                Simulate optical loss across fiber distance and passive splitters before deploying new connections.
              </p>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-300 mb-1">OLT SFP Transceiver Tx Power (dBm)</label>
                  <input
                    type="number"
                    step="0.5"
                    value={calcTxPower}
                    onChange={(e) => setCalcTxPower(parseFloat(e.target.value) || 0)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Distance to Customer ONU (km): {calcDistance} km</label>
                  <input
                    type="range"
                    min="0.2"
                    max="15"
                    step="0.1"
                    value={calcDistance}
                    onChange={(e) => setCalcDistance(parseFloat(e.target.value))}
                    className="w-full accent-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Asymmetric / PLC Splitter Ratio</label>
                  <select
                    value={calcSplitter}
                    onChange={(e) => setCalcSplitter(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                  >
                    <option value="1:4">1:4 PLC Splitter (-7.0 dB loss)</option>
                    <option value="1:8">1:8 PLC Splitter (-10.5 dB loss)</option>
                    <option value="1:16">1:16 PLC Splitter (-14.0 dB loss)</option>
                    <option value="1:32">1:32 PLC Splitter (-17.5 dB loss)</option>
                  </select>
                </div>
              </div>

              {/* Calculated Result Card */}
              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2">
                <div className="text-xs text-slate-400">Estimated Rx Optical Power:</div>
                <div className={`text-3xl font-bold font-mono ${
                  parseFloat(calculatedRxSignal) < -25.0 ? 'text-rose-400' : 'text-emerald-400'
                }`}>
                  {calculatedRxSignal} dBm
                </div>

                {parseFloat(calculatedRxSignal) < -25.0 ? (
                  <div className="flex items-center space-x-1.5 text-xs text-rose-400 bg-rose-500/10 p-2 rounded-lg border border-rose-500/20">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>Warning: Weak Signal! High risk of packet loss or LOS.</span>
                  </div>
                ) : (
                  <div className="flex items-center space-x-1.5 text-xs text-emerald-400 bg-emerald-500/10 p-2 rounded-lg border border-emerald-500/20">
                    <CheckCircle className="w-4 h-4 shrink-0" />
                    <span>Optimal signal range for 1G/10G ONU.</span>
                  </div>
                )}
              </div>
            </div>

            {/* Network Optical Power List */}
            <div className="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="font-bold text-slate-100 flex items-center space-x-2">
                <Server className="w-5 h-5 text-cyan-400" />
                <span>Live Optical Power Readings by Customer</span>
              </h3>

              <div className="space-y-3">
                {customers.map((c) => {
                  const rxNum = parseFloat(c.opticalSignal);
                  const isWeak = rxNum < -25.0;

                  return (
                    <div key={c.id} className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                      <div className="space-y-1">
                        <div className="font-semibold text-slate-100">{c.name} ({c.id})</div>
                        <div className="text-slate-400 flex items-center space-x-3 font-mono text-[11px]">
                          <span>PON: {c.oltPort}</span>
                          <span>MAC: {c.onuMac}</span>
                          <span>Dist: {c.distanceKm || '1.5'} km</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className={`font-mono text-base font-bold ${isWeak ? 'text-rose-400' : 'text-emerald-400'}`}>
                          {c.opticalSignal} dBm
                        </span>
                        <div className="text-[10px] text-slate-500">{isWeak ? 'Critical dBm' : 'Healthy Rx'}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* --- TAB 3: TICKETS & COMPLAINTS --- */}
        {activeTab === 'tickets' && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-bold text-lg text-slate-100">{t.tickets}</h3>
                <p className="text-xs text-slate-400">Manage field issues, optical fiber breaks, and router configurations</p>
              </div>

              <button
                onClick={() => setIsTicketModalOpen(true)}
                className="bg-cyan-600 hover:bg-cyan-500 text-white px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center space-x-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>{t.createNewTicket}</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {tickets.map(tck => (
                <div key={tck.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono text-xs bg-slate-950 text-cyan-400 border border-slate-800 px-2 py-0.5 rounded">
                        {tck.id}
                      </span>
                      <h4 className="font-semibold text-slate-100 mt-1">{tck.customerName}</h4>
                      <p className="text-xs text-slate-400">{tck.phone} | {tck.branch}</p>
                    </div>

                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      tck.priority === 'High' ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30' : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                    }`}>
                      {tck.priority} Priority
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 bg-slate-950 p-2.5 rounded-lg border border-slate-800/60">
                    "{tck.issue}"
                  </p>

                  <div className="flex justify-between items-center text-xs text-slate-400 pt-1">
                    <span>Tech: <strong className="text-slate-200">{tck.tech}</strong></span>
                    <span className="bg-slate-800 px-2 py-0.5 rounded text-cyan-300">{tck.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* --- TAB 4: SETTINGS & BRANCH MANAGER --- */}
        {activeTab === 'settings' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* Branch Locations Manager */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="font-bold text-slate-100 flex items-center space-x-2">
                <Building2 className="w-5 h-5 text-cyan-400" />
                <span>Branch Locations / Wards</span>
              </h3>

              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. Nijgadh Ward No. 9"
                  value={newBranchInput}
                  onChange={(e) => setNewBranchInput(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200"
                />
                <button
                  onClick={handleAddBranch}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold"
                >
                  {t.addBranch}
                </button>
              </div>

              <div className="space-y-2">
                {branches.map((b, idx) => (
                  <div key={idx} className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800 flex justify-between items-center text-xs">
                    <span className="text-slate-200">{b}</span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">Active Region</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Internet Package Settings */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-5 space-y-4">
              <h3 className="font-bold text-slate-100 flex items-center space-x-2">
                <Package className="w-5 h-5 text-cyan-400" />
                <span>FTTH Speed Packages & Pricing</span>
              </h3>

              <div className="grid grid-cols-3 gap-2">
                <input
                  type="text"
                  placeholder="Package Name"
                  value={newPkgInput.name}
                  onChange={(e) => setNewPkgInput({ ...newPkgInput, name: e.target.value })}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
                />
                <input
                  type="number"
                  placeholder="Monthly Price (NPR)"
                  value={newPkgInput.price}
                  onChange={(e) => setNewPkgInput({ ...newPkgInput, price: e.target.value })}
                  className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200"
                />
                <button
                  onClick={handleAddPackage}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold"
                >
                  {t.addPackage}
                </button>
              </div>

              <div className="space-y-2">
                {packages.map((pkg) => (
                  <div key={pkg.id} className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex justify-between items-center text-xs">
                    <div>
                      <div className="font-semibold text-slate-200">{pkg.name}</div>
                      <div className="text-[11px] text-slate-400">Base: रु. {pkg.price} + 13% VAT (रु. {pkg.tax.toFixed(1)})</div>
                    </div>
                    <div className="text-right font-mono text-cyan-400 font-bold">
                      रु. {(pkg.price + pkg.tax).toFixed(0)} / mo
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

      </main>

      {/* --- MODAL 1: REGISTER SUBSCRIBER --- */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <Plus className="w-4 h-4 text-cyan-400" />
                {t.registerTitle}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCustomer} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">{t.name} *</label>
                <input
                  required
                  type="text"
                  placeholder="e.g. Nabin Karki"
                  value={newCust.name}
                  onChange={(e) => setNewCust({ ...newCust, name: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">{t.mobile} *</label>
                  <input
                    required
                    type="tel"
                    placeholder="98XXXXXXXX"
                    value={newCust.mobile}
                    onChange={(e) => setNewCust({ ...newCust, mobile: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">{t.branch} *</label>
                  <select
                    value={newCust.branch}
                    onChange={(e) => setNewCust({ ...newCust, branch: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                  >
                    {branches.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">{t.package} *</label>
                <select
                  value={newCust.package}
                  onChange={(e) => setNewCust({ ...newCust, package: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                >
                  {packages.map(p => (
                    <option key={p.id} value={p.name}>{p.name} (रु. {p.price}/mo)</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-3 gap-3 pt-2 border-t border-slate-800">
                <div>
                  <label className="block text-slate-400 mb-1">{t.oltPort}</label>
                  <input
                    type="text"
                    value={newCust.oltPort}
                    onChange={(e) => setNewCust({ ...newCust, oltPort: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 font-mono text-[11px]"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.fiberLength}</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newCust.distanceKm}
                    onChange={(e) => setNewCust({ ...newCust, distanceKm: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-slate-200 font-mono text-[11px]"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">{t.splitterRatio}</label>
                  <select
                    value={newCust.splitter}
                    onChange={(e) => setNewCust({ ...newCust, splitter: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2 py-1.5 text-slate-200 text-[11px]"
                  >
                    <option value="1:8">1:8</option>
                    <option value="1:16">1:16</option>
                    <option value="1:32">1:32</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                >
                  {t.close}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-lg"
                >
                  {t.saveCustomer}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 2: RENEW SUB --- */}
      {renewingCustomer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-cyan-400" />
                Renewal & Bill Payment
              </h3>
              <button onClick={() => setRenewingCustomer(null)} className="text-slate-400 hover:text-slate-200">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <p className="font-bold text-slate-200">{renewingCustomer.name}</p>
                <p className="text-slate-400">{renewingCustomer.package} | रु. {renewingCustomer.price}/month</p>
              </div>

              <p className="text-slate-300 font-medium">Select Duration:</p>

              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => handleRenew(1)}
                  className="p-3 bg-slate-800 hover:bg-cyan-600/20 border border-slate-700 rounded-xl text-center"
                >
                  <p className="font-bold text-white">1 Month</p>
                  <p className="text-slate-400 text-[11px]">रु. {renewingCustomer.price * 1}</p>
                </button>
                <button
                  onClick={() => handleRenew(3)}
                  className="p-3 bg-slate-800 hover:bg-cyan-600/20 border border-slate-700 rounded-xl text-center"
                >
                  <p className="font-bold text-white">3 Months</p>
                  <p className="text-slate-400 text-[11px]">रु. {renewingCustomer.price * 3}</p>
                </button>
                <button
                  onClick={() => handleRenew(12)}
                  className="p-3 bg-slate-800 hover:bg-cyan-600/20 border border-slate-700 rounded-xl text-center"
                >
                  <p className="font-bold text-white">1 Year</p>
                  <p className="text-slate-400 text-[11px]">रु. {renewingCustomer.price * 12}</p>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL 3: NEPALI VAT RECEIPT GENERATOR --- */}
      {receiptData && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            
            {/* Printable Receipt Container */}
            <div id="receipt-print-area" className="p-6 bg-white text-slate-900 space-y-4">
              <div className="text-center border-b pb-3 border-slate-300">
                <h2 className="text-xl font-bold uppercase tracking-wide">हाम्रो NET FTTH</h2>
                <p className="text-[11px] text-slate-600">Nijgadh, Bara, Nepal | Tel: 053-520123</p>
                <p className="text-[11px] font-semibold text-slate-700">{t.vatNo}</p>
                <div className="mt-2 text-xs font-bold bg-slate-100 inline-block px-3 py-1 rounded">
                  {t.receiptTitle}
                </div>
              </div>

              <div className="grid grid-cols-2 text-[11px] gap-1">
                <div><strong>Invoice No:</strong> {receiptData.invoiceNo}</div>
                <div className="text-right"><strong>Date:</strong> {receiptData.date}</div>
                <div><strong>Subscriber:</strong> {receiptData.customer.name}</div>
                <div className="text-right"><strong>ID:</strong> {receiptData.customer.id}</div>
                <div><strong>Branch:</strong> {receiptData.customer.branch}</div>
                <div className="text-right"><strong>Payment:</strong> Cash / eSewa</div>
              </div>

              <table className="w-full text-[11px] text-left border-t border-b border-slate-300 py-2">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-600">
                    <th className="py-1">Description</th>
                    <th className="py-1 text-right">Amount (NPR)</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="py-1">{receiptData.customer.package} ({receiptData.months} mo)</td>
                    <td className="py-1 text-right">रु. {receiptData.subTotal.toFixed(2)}</td>
                  </tr>
                  <tr>
                    <td className="py-1 text-slate-600">13% Value Added Tax (VAT)</td>
                    <td className="py-1 text-right font-mono">रु. {receiptData.vatAmount.toFixed(2)}</td>
                  </tr>
                </tbody>
              </table>

              <div className="flex justify-between items-center text-xs font-bold pt-1">
                <span>Grand Total:</span>
                <span className="text-base font-mono">रु. {receiptData.totalWithVat.toFixed(2)}</span>
              </div>

              <div className="text-[10px] text-center text-slate-500 pt-3 border-t border-slate-200">
                Thank you for choosing Hamro NET FTTH Internet Service!
              </div>
            </div>

            <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end space-x-2">
              <button
                onClick={() => setReceiptData(null)}
                className="px-3 py-1.5 bg-slate-800 text-xs text-slate-300 rounded"
              >
                {t.close}
              </button>
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded flex items-center space-x-1"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{t.printInvoice}</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* --- MODAL 4: TICKET CREATION --- */}
      {isTicketModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
              <h3 className="font-bold text-sm text-slate-100">{t.createNewTicket}</h3>
              <button onClick={() => setIsTicketModalOpen(false)} className="text-slate-400 hover:text-slate-200">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddTicket} className="p-5 space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Subscriber Name *</label>
                <input
                  required
                  type="text"
                  value={newTicket.customerName}
                  onChange={(e) => setNewTicket({ ...newTicket, customerName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Issue Details *</label>
                <textarea
                  required
                  rows="3"
                  placeholder="e.g. Fiber optical link down, LOS blinking on router"
                  value={newTicket.issue}
                  onChange={(e) => setNewTicket({ ...newTicket, issue: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                ></textarea>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 mb-1">Priority</label>
                  <select
                    value={newTicket.priority}
                    onChange={(e) => setNewTicket({ ...newTicket, priority: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Technician</label>
                  <input
                    type="text"
                    value={newTicket.tech}
                    onChange={(e) => setNewTicket({ ...newTicket, tech: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-slate-200"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsTicketModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded-lg"
                >
                  {t.close}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold rounded-lg"
                >
                  Submit Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- MODAL 5: CUSTOMER DETAILS --- */}
      {viewingCustomer && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl text-slate-200">
            <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
              <h3 className="font-bold text-sm text-slate-100">Subscriber Technical Dossier</h3>
              <button onClick={() => setViewingCustomer(null)} className="text-slate-400 hover:text-slate-200">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-3 text-xs">
              <div className="bg-slate-950 p-3 rounded-lg border border-slate-800">
                <h4 className="font-bold text-base text-white">{viewingCustomer.name}</h4>
                <p className="text-cyan-400 font-mono text-xs">{viewingCustomer.id}</p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-slate-300">
                <div><span className="text-slate-500">Mobile:</span> {viewingCustomer.mobile}</div>
                <div><span className="text-slate-500">Branch:</span> {viewingCustomer.branch}</div>
                <div><span className="text-slate-500">Package:</span> {viewingCustomer.package}</div>
                <div><span className="text-slate-500">Price:</span> रु. {viewingCustomer.price}</div>
                <div><span className="text-slate-500">OLT Port:</span> {viewingCustomer.oltPort}</div>
                <div><span className="text-slate-500">ONU MAC:</span> {viewingCustomer.onuMac}</div>
                <div><span className="text-slate-500">Distance:</span> {viewingCustomer.distanceKm || '1.5'} km</div>
                <div><span className="text-slate-500">Signal:</span> <strong className="text-emerald-400">{viewingCustomer.opticalSignal} dBm</strong></div>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}